--this query will mark receipt records as removed at detail level

update shipment set invc_match_status='M' where invc_match_status='U' and (shipment,order_no) in 
(
(13600052,15853506),
(13618766,15852027),
(13554642,15786482)
);