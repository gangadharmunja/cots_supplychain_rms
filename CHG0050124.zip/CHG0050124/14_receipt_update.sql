update shipment set INVC_MATCH_STATUS='U' where shipment in 
('14030819');