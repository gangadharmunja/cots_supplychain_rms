/* below count results no of receipts before executing Receipt_Creation.sql script */
-- expected count id 01 (may change due to daily jobs)

  select count(*) from  shipment where shipment 
 in ('14030819') and INVC_MATCH_STATUS='M';