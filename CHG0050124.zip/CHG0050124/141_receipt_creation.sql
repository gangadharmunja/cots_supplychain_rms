--creation of receipts

DECLARE

    L_error_message varchar2(4000);

               RAC_CREATE_SHIPMENT_FAIL   EXCEPTION;

BEGIN

create_shipment (16136369,496,200047305,9,128.06,1,1,L_error_message);
create_shipment (16054683,7223,100028908,2,850,1,1,L_error_message);


IF L_error_message IS NOT NULL THEN

      L_error_message := 'ERROR ' || L_error_message;

      dbms_output.put_line(L_error_message);     

    END IF;

   

EXCEPTION

   WHEN OTHERS THEN

      ROLLBACK;

      L_error_message := 'ERROR ' || SQLERRM;

      dbms_output.put_line(L_error_message);

END;

/
