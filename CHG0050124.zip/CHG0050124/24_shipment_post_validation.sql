--count of below query should be zero after update

SELECT count(*) FROM SHIPMENT WHERE (shipment,order_no) in
(
(13600052,15853506),
(13618766,15852027),
(13554642,15786482)) and invc_match_status='U';