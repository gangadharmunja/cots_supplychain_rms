--count of below query should be updated

SELECT count(*) FROM SHIPMENT WHERE (SHIPMENT,ORDER_NO) IN
(
(13600052,15853506),
(13618766,15852027),
(13554642,15786482)) and invc_match_status='U';


