/* below query is used to get the no of records that are in reject table and those are need to be inserted into RAC_CS_SIMS_HEAD and RAC_CS_IMPORT_ARCHV */

/* count resulted from below query should be same as no of records inserted into RAC_CS_SIMS_HEAD and also same as no of records inserted into RAC_CS_IMPORT_ARCHV */

SELECT count(*)
     FROM rac_cs_import_reject rcir
        , rac_im_invoices_head_rej ihr
        , rac_im_invoices_detail_rej idr
    WHERE rcir.rej_code = 'CO'
      AND ihr.order_no = rcir.order_no
      AND ihr.doc_id = idr.doc_id
      AND idr.item = rcir.item
      AND ihr.status = 'R'
      AND ihr.rej_code = 'TQ'
        ;