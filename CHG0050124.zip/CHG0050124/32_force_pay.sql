-- posting invoices to finance

update rac_im_lawsonposting_stage lps set lps.cs_create_date = get_vdate(),lps.cs_accounting_date =trunc(last_day(sysdate))
where doc_id in ('20441205',
'20448300',
'20454521'); 


