/* count should be same as no of rows should be updated */
select count(*)
from RAC_CS_SIMS_HEAD 
where rac_serialized_unit_no in 
('9999221141283',
'9999221154832',
'9999221160312',
'9999221179937',
'9999221207059',
'9999221207063',
'9999221221390')and doc_id is null;








