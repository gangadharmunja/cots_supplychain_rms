-- updating doc_id
update rac_cs_sims_head set doc_id=19365504 where rac_serialized_unit_no='9999221141283';
update rac_cs_sims_head set doc_id=19377026 where rac_serialized_unit_no='9999221154832';
update rac_cs_sims_head set doc_id=19403092 where rac_serialized_unit_no='9999221160312';

update rac_cs_sims_head set doc_id=19461672 where rac_serialized_unit_no='9999221179937';

update rac_cs_sims_head set doc_id=19465998 where rac_serialized_unit_no='9999221207059';
update rac_cs_sims_head set doc_id=19465998 where rac_serialized_unit_no='9999221207063';
update rac_cs_sims_head set doc_id=19470677 where rac_serialized_unit_no='9999221221390';









