/* below count results no of receipts before executing Receipt_Creation.sql script */
-- expected count id 11 (may change due to daily jobs)

  select count(*) from  shipment where shipment 
 in ('13645451',
'13663060',
'13633711',
'13645857',
'13662733',
'13666438',
'13676535',
'13666768',
'13707867',
'13701142',
'13707425') and INVC_MATCH_STATUS='M';
 

 
