update shipment set INVC_MATCH_STATUS='U' where shipment in 
('13943738','13940408','13968240','14026240');