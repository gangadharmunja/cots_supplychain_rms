-- updating doc_id

update rac_cs_sims_head set doc_id=18945401 where rac_serialized_unit_no='9999220816506';

update rac_cs_sims_head set doc_id=18250186 where rac_serialized_unit_no='9999220903285';











