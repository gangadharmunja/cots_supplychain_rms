/* below query will give the records of open receipts that came after invoices paid for RFI stores which need to be removed */

/* after executing RFI_automation_script.sql below query should not reflect any records which means all records that need to be removed are marked as removed */

SELECT count(*)
  FROM (((RMSADMIN.RAC_STORE_CODES RAC_STORE_CODES
          INNER JOIN REIMRPT.SHIPMENT SHIPMENT
             ON RAC_STORE_CODES.STORE = SHIPMENT.TO_LOC)
         INNER JOIN REIMRPT.RAC_V_ORDHEAD_PENDING RAC_V_ORDHEAD_PENDING
            ON SHIPMENT.ORDER_NO = RAC_V_ORDHEAD_PENDING.ORDER_NO)
        INNER JOIN REIMRPT.SHIPSKU SHIPSKU
           ON SHIPMENT.SHIPMENT = SHIPSKU.SHIPMENT)
       INNER JOIN REIMRPT.RAC_V_SUPS RAC_V_SUPS
          ON RAC_V_ORDHEAD_PENDING.SUPPLIER = RAC_V_SUPS.SUPPLIER
WHERE     SHIPMENT.INVC_MATCH_STATUS = 'U'
       AND (   SHIPSKU.INVC_MATCH_STATUS = 'P'
            OR SHIPSKU.INVC_MATCH_STATUS = 'U')
       AND RAC_STORE_CODES.STORE_TYPE = 'RFI'
       AND NVL (qty_received, 0) > NVL (qty_matched, 0)
       AND EXISTS
              (SELECT 1
                 FROM ordhead oh, ordloc ol, rac_store_codes rsc
                WHERE     oh.order_no = ol.order_no
                      AND rsc.store = ol.location
                      AND rsc.store_type = 'RFI'
                      AND oh.order_no = RAC_V_ORDHEAD_PENDING.ORDER_NO
                      AND ol.item = SHIPSKU.ITEM
                      AND ol.qty_ordered <=
                             (SELECT SUM (iid.invoice_qty)
                                FROM im_doc_head idh, im_invoice_detail iid
                               WHERE     idh.doc_id = iid.doc_id
                                     AND idh.status = 'POSTED'
                                     AND idh.order_no = ol.order_no
                                     AND iid.item = ol.item))
       AND NOT EXISTS
                  (SELECT 1
                     FROM im_doc_head idh, im_invoice_detail iid
                    WHERE     idh.doc_id = iid.doc_id
                          AND idh.status NOT IN ('POSTED', 'DELETE')
                          AND idh.order_no = RAC_V_ORDHEAD_PENDING.ORDER_NO
                          AND iid.item = SHIPSKU.ITEM);