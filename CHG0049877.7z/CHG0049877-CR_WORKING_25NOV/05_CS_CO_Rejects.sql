set serveroutput on
set termout on
set feedback on


---
-- Serialized Items in rac_cs_import_reject with rej_code 'CO'.
-- Move these serialized items into RAC_CS_SIMS_HEAD and RAC_CS_IMPORT_ARCHV.
---

DECLARE

   LV_Message   VARCHAR2(1000);

   CURSOR C_Reject IS
   SELECT ihr.supplier
        , rcir.accounting_posting_date
        , rcir.order_no
        , ihr.invoice_number
        , rcir.rac_serialized_unit_no
        , rcir.item
        , ihr.location
     FROM rac_cs_import_reject rcir
        , rac_im_invoices_head_rej ihr
        , rac_im_invoices_detail_rej idr
    WHERE rcir.rej_code = 'CO'
      AND ihr.order_no = rcir.order_no
      AND ihr.doc_id = idr.doc_id
      AND idr.item = rcir.item
      AND ihr.status = 'R'
      AND ihr.rej_code = 'TQ'
        ;

BEGIN

   FOR Ndx IN C_Reject LOOP

      LV_Message := 'Supplier: ' || Ndx.supplier
                 || ' AP_Date: ' || Ndx.accounting_posting_date
                 || ' PO: '      || Ndx.order_no
                 || ' Invoice: ' || Ndx.invoice_number
                 || ' HT_Info: ' || Ndx.rac_serialized_unit_no
                 || ' Item: '    || Ndx.item
                 || ' Store: '   || Ndx.location
                 ;

      INSERT INTO RAC_CS_SIMS_HEAD
                             ( rac_serialized_unit_no
                             , store
                             , item
                             , model_no
                             , order_no
                             , po_line_number
                             , po_unit_cost
                             , record_type
                             , non_inv_item
                             , create_id
                             , create_date
                             , update_id
                             , update_date
                             )
                        SELECT rac_serialized_unit_no
                             , store
                             , item
                             , model_no
                             , order_no
                             , po_line_number
                             , po_unit_cost
                             , record_type
                             , NVL(non_inv_item, 'N')
                             , create_id
                             , create_date
                             , update_id
                             , update_date
                          FROM rac_cs_import_reject
                         WHERE rac_serialized_unit_no = Ndx.rac_serialized_unit_no;
 
      INSERT INTO RAC_CS_IMPORT_ARCHV
                             ( rac_serialized_unit_no
                             , accounting_posting_date
                             , store
                             , item
                             , model_no
                             , order_no
                             , po_line_number
                             , estimated_cost
                             , record_type
                             , create_id
                             , create_date
                             , update_id
                             , update_date
                             , po_unit_cost
                             , costcomp_id1
                             , costcomp_id1_amt
                             , costcomp_id2
                             , costcomp_id2_amt
                             , costcomp_id3
                             , costcomp_id3_amt
                             , costcomp_id4
                             , costcomp_id4_amt
                             , costcomp_id5
                             , costcomp_id5_amt
                             , costcomp_id6
                             , costcomp_id6_amt
                             , costcomp_id7
                             , costcomp_id7_amt
                             , costcomp_id8
                             , costcomp_id8_amt
                             , costcomp_id9
                             , costcomp_id9_amt
                             , costcomp_id10
                             , costcomp_id10_amt
                             , non_inv_item
                             , import_status
                             , import_date )
                        SELECT rac_serialized_unit_no
                             , accounting_posting_date
                             , store
                             , item
                             , model_no
                             , order_no
                             , po_line_number
                             , estimated_cost
                             , record_type
                             , create_id
                             , create_date
                             , update_id
                             , update_date
                             , po_unit_cost
                             , costcomp_id1
                             , costcomp_id1_amt
                             , costcomp_id2
                             , costcomp_id2_amt
                             , costcomp_id3
                             , costcomp_id3_amt
                             , costcomp_id4
                             , costcomp_id4_amt
                             , costcomp_id5
                             , costcomp_id5_amt
                             , costcomp_id6
                             , costcomp_id6_amt
                             , costcomp_id7
                             , costcomp_id7_amt
                             , costcomp_id8
                             , costcomp_id8_amt
                             , costcomp_id9
                             , costcomp_id9_amt
                             , costcomp_id10
                             , costcomp_id10_amt
                             , NVL(non_inv_item, 'N')
                             , import_status
                             , import_date
                          FROM rac_cs_import_reject
                         WHERE rac_serialized_unit_no = Ndx.rac_serialized_unit_no;
 

      DELETE FROM rac_cs_import_reject
            WHERE rac_serialized_unit_no = Ndx.rac_serialized_unit_no;
 
   END LOOP;

EXCEPTION
   when OTHERS then
      DBMS_OUTPUT.PUT_LINE('!!!FAILURE!!!');
      DBMS_OUTPUT.PUT_LINE(LV_Message);
      ROLLBACK;
END;
/

