--this query will mark receipt records as removed at detail level

update  shipment set invc_match_status='M' where invc_match_status='U' and (shipment,order_no) in 
(
(14034239,16094080),
(13604619,15876372),
(13609461,15907791), 
(13630551,15891302), 
(13724962,15921390)
);