-- posting invoices to finance

update rac_im_lawsonposting_stage lps set lps.cs_create_date = get_vdate(),lps.cs_accounting_date =trunc(last_day(sysdate))
where doc_id in ('20228858',
'20228859',
'19701321',
'20228847',
'20228846',
'20228855',
'19489630',
'20228845'); 


