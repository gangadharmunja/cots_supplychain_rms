/* this below query will reflect in no of records that are same but has different bol number in rac_asnout_int_stg and rac_receipt_int_stg tables */

/* at the time of execution of bol_update.sql script count resulted by below query should be same as no of records updated */

select count(*) from rac_asnout_int_stg a, rac_receipt_int_stg b
where a.distro_no=b.doc_no
and a.item_no=b.item
and ((a.unit_qty>b.qty_received) or (a.unit_qty=b.qty_received))
and a.bol_no<>b.bol_no
and a.status_code='S'
AND b.STATUS_CODE='P';