/* this query will remove open receipts that are received after invoice is paid off for RFI store */

SET SERVEROUTPUT ON;
DECLARE
    CURSOR abc IS
    SELECT RAC_V_SUPS.SUPPLIER,
       RAC_V_SUPS.SUP_NAME,
       RAC_V_ORDHEAD_PENDING.ORDER_NO,
       SHIPMENT.SHIPMENT,
       SHIPSKU.ITEM,
       SHIPSKU.UNIT_COST,
       SHIPMENT.RECEIVE_DATE,
       SHIPSKU.QTY_RECEIVED,
       SHIPSKU.QTY_MATCHED,
       SHIPMENT.INVC_MATCH_STATUS AS SHIPMENT_IMS,
       RAC_V_SUPS.SUP_ID_AND_NAME,
       SHIPSKU.INVC_MATCH_STATUS AS SHIPSKU_IMS,
       RAC_STORE_CODES.STORE,
       RAC_STORE_CODES.STORE_TYPE
  FROM (((RMSADMIN.RAC_STORE_CODES RAC_STORE_CODES
          INNER JOIN REIMRPT.SHIPMENT SHIPMENT
             ON RAC_STORE_CODES.STORE = SHIPMENT.TO_LOC)
         INNER JOIN REIMRPT.RAC_V_ORDHEAD_PENDING RAC_V_ORDHEAD_PENDING
            ON SHIPMENT.ORDER_NO = RAC_V_ORDHEAD_PENDING.ORDER_NO)
        INNER JOIN REIMRPT.SHIPSKU SHIPSKU
           ON SHIPMENT.SHIPMENT = SHIPSKU.SHIPMENT)
       INNER JOIN REIMRPT.RAC_V_SUPS RAC_V_SUPS
          ON RAC_V_ORDHEAD_PENDING.SUPPLIER = RAC_V_SUPS.SUPPLIER
WHERE     SHIPMENT.INVC_MATCH_STATUS = 'U'
       AND (   SHIPSKU.INVC_MATCH_STATUS = 'P'
            OR SHIPSKU.INVC_MATCH_STATUS = 'U')
       AND RAC_STORE_CODES.STORE_TYPE = 'RFI'
       AND NVL (qty_received, 0) > NVL (qty_matched, 0)
       AND EXISTS
              (SELECT 1
                 FROM ordhead oh, ordloc ol, rac_store_codes rsc
                WHERE     oh.order_no = ol.order_no
                      AND rsc.store = ol.location
                      AND rsc.store_type = 'RFI'
                      AND oh.order_no = RAC_V_ORDHEAD_PENDING.ORDER_NO
                      AND ol.item = SHIPSKU.ITEM
                      AND ol.qty_ordered <=
                             (SELECT SUM (iid.invoice_qty)
                                FROM im_doc_head idh, im_invoice_detail iid
                               WHERE     idh.doc_id = iid.doc_id
                                     AND idh.status = 'POSTED'
                                     AND idh.order_no = ol.order_no
                                     AND iid.item = ol.item))
       AND NOT EXISTS
                  (SELECT 1
                     FROM im_doc_head idh, im_invoice_detail iid
                    WHERE     idh.doc_id = iid.doc_id
                          AND idh.status NOT IN ('POSTED', 'DELETE')
                          AND idh.order_no = RAC_V_ORDHEAD_PENDING.ORDER_NO
                          AND iid.item = SHIPSKU.ITEM);

   
       cnt NUMBER := 0;
BEGIN 
    FOR i IN abc
    LOOP 
    
update shipsku set qty_matched=-1, qty_received=-1,invc_match_status='M' where invc_match_status='U' and (shipment,item) in ((i.shipment,i.item));
  cnt := cnt + 1;
update  shipment set invc_match_status='M' , comments='RFI receipt clean up' where invc_match_status='U' and (shipment,order_no) in ((i.shipment,i.order_no));
  cnt := cnt + 1;
        
      
    
    END LOOP;
    dbms_output.put_line('Total rows updated - ' || cnt);
END;
/

        
