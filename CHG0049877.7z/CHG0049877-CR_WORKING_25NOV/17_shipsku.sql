--this query will mark receipt records as removed at header level

update shipsku set qty_matched=-1, qty_received=-1,invc_match_status='M' where invc_match_status='U' and (shipment,item) in 
(
(14034239,200050406),
(13604619,200053768),
(13609461,200037926),
(13630551,200048925),
(13724962,200050156)
);











 
