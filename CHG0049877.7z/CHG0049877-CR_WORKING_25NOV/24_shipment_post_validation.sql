--count of below query should be zero after update

SELECT count(*) FROM SHIPMENT WHERE (shipment,order_no) in
((14034239,16094080),
(13604619,15876372),
(13609461,15907791), 
(13630551,15891302), 
(13724962,15921390)) and invc_match_status='U';