 /* below count should be same as no of records updated */
   
   SELECT count(*)
     FROM rac_im_lawsonposting_stage
        where doc_id in ('20228858',
'20228859',
'19701321',
'20228847',
'20228846',
'20228855',
'19489630',
'20228845');
		