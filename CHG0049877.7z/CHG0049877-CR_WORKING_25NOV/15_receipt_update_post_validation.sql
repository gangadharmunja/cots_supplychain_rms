/* below count results no of receipts after executing Receipt_Creation.sql script */
-- expected count id 04 (may change due to daily jobs)

  
 select count(*) from  shipment where shipment in ('13943738','13940408','13968240','14026240') and INVC_MATCH_STATUS='U';