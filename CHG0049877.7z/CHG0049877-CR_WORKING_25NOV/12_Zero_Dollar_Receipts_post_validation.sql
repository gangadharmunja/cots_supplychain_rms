/* below query will result no of records that need to be updated which means the no of records that are matched at detail level and not yet marked as matched at header level */

/* after execution of Zero_Dollar_Receipts.sql script below query should reflect zero count */

SELECT count(DISTINCT SHIPMENT.SHIPMENT)
                      FROM ((REIMRPT.SHIPMENT SHIPMENT
                             INNER JOIN
                             REIMRPT.RAC_V_ORDHEAD_PENDING RAC_V_ORDHEAD_PENDING
                                ON SHIPMENT.ORDER_NO =
                                      RAC_V_ORDHEAD_PENDING.ORDER_NO)
                            INNER JOIN REIMRPT.SHIPSKU SHIPSKU
                               ON SHIPMENT.SHIPMENT = SHIPSKU.SHIPMENT)
                           INNER JOIN REIMRPT.RAC_V_SUPS RAC_V_SUPS
                              ON RAC_V_ORDHEAD_PENDING.SUPPLIER =
                                    RAC_V_SUPS.SUPPLIER
                     WHERE     SHIPMENT.INVC_MATCH_STATUS = 'U'
                           AND (   SHIPSKU.INVC_MATCH_STATUS = 'P'
                                OR SHIPSKU.INVC_MATCH_STATUS = 'U')
                           AND NVL (SHIPSKU.QTY_RECEIVED, 0) <= 0
                           AND SHIPMENT.RECEIVE_DATE IS NOT NULL
                           --AND SHIPMENT.ORDER_NO = '8965293'
                           AND NOT EXISTS
                                      (SELECT 1
                                         FROM im_doc_head
                                        WHERE     order_no =
                                                     RAC_V_ORDHEAD_PENDING.ORDER_NO
                                              AND status NOT IN ('VOID',
                                                                 'DELETE',
                                                                 'POSTED'))
                           AND EXISTS
                                  (SELECT 1
                                     FROM ordhead oh1
                                    WHERE oh1.order_no =
                                             RAC_V_ORDHEAD_PENDING.ORDER_NO)
                           AND ( (SELECT SUM (idd.resolution_adjusted_qty)
                                    FROM im_doc_head idh,
                                         im_invoice_detail idd
                                   WHERE     RAC_V_ORDHEAD_PENDING.ORDER_NO =
                                                idh.order_no
                                         AND idh.TYPE = 'MRCHI'
                                         AND idh.status = 'POSTED'
                                         AND idd.doc_id = idh.doc_id) >=
                                   (SELECT SUM (ol2.qty_ordered)
                                      FROM ordloc ol2
                                     WHERE ol2.order_no =
                                              RAC_V_ORDHEAD_PENDING.ORDER_NO));