  /* below count should be zero after script execution */
  
   SELECT count(*)
     FROM rac_im_lawsonposting_stage
        where doc_id in ('20228858',
'20228859',
'19701321',
'20228847',
'20228846',
'20228855',
'19489630',
'20228845') and cs_create_date is null;