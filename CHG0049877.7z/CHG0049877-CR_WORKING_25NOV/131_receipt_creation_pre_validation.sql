/* below count results no of receipts before executing Receipt_Creation.sql script */
-- expected count id 02 (may change due to daily jobs)

   SELECT count(*)
     FROM shipment sh
        , shipsku sk
    WHERE (sh.order_no,sk.item) in ((16094080,200050406))
      AND sh.shipment = sk.shipment
	  AND sh.invc_match_status='U'
	  AND sk.invc_match_status='U'
        ;
		
