/* below count results no of receipts before executing Receipt_Creation.sql script */
-- expected count id 13 (may change due to daily jobs)

  select count(*) from  shipment where shipment 
 in ('13961798','13941296','13993015','14031891','14067924','14049571'
'14066883','14091680','14061685','14117969','14124626','14124649','14043926') and INVC_MATCH_STATUS='M';