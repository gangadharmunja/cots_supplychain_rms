
insert into rac_costing_solution_export (RAC_SERIALIZED_UNIT_NO, ACCOUNTING_POSTING_DATE, STORE, ITEM, MODEL_NO, ORDER_NO, PO_LINE_NUMBER, ESTIMATED_COST,UPDATE_DATE, record_type,
CREATE_ID, CREATE_DATE, UPDATE_ID, po_unit_cost, non_inv_item , pub_ind,INVOICE_ID)
select RAC_SERIALIZED_UNIT_NO, '01-Jan-26', STORE, ITEM, MODEL_NO, ORDER_NO, PO_LINE_NUMBER, po_unit_cost,
sysdate, record_type, 'RMSADMIN', sysdate, 'RMSADMIN', po_unit_cost, non_inv_item , 'N',
(select ext_doc_id from im_doc_head where im_doc_head.order_no=rac_cs_sims_head.order_no and im_doc_head.doc_id=rac_cs_sims_head.doc_id)
from rac_cs_sims_head
where rac_serialized_unit_no in 
('9999221289401',
'9999221252987',
'9999221251561',
'9999221260660',
'9999221273321',
'9999221354082',
'9999221354083',
'9999221276074',
'9999221351495',
'9999221352938',
'9999221322347',
'9999221293931',
'9999221360349',
'9999221280487'
)
and doc_id is not null;

