 /* below count should be same as no of records updated */
   
   SELECT count(*)
     FROM rac_im_lawsonposting_stage
        where doc_id in ('20292461',
'19827179','20439136');
		