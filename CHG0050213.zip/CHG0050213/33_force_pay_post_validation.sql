  /* below count should be zero after script execution */
  
   SELECT count(*)
     FROM rac_im_lawsonposting_stage
        where doc_id in ('20292461',
'19827179','20439136') and cs_create_date is null;