--count of below query should be zero after update

select count(*) from shipsku where (shipment,item) in ((14034239,200050406),
(13604619,200053768),
(13609461,200037926),
(13630551,200048925),
(13724962,200050156)) and invc_match_status='U';