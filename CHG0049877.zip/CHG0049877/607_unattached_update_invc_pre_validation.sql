/* count should be same as no of rows should be updated */

select count(*)
from RAC_CS_SIMS_HEAD 
where rac_serialized_unit_no in 
('9999220816506','9999220903285');


