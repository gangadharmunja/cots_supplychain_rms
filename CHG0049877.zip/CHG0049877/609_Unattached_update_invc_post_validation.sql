/* count should be zero after execution of script */

select count(*)
from RAC_CS_SIMS_HEAD
where  rac_serialized_unit_no in
('9999220816506','9999220903285')
and doc_id is null; 


