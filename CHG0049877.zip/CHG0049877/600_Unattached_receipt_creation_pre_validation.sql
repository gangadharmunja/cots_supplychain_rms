/* below count results no of receipts before executing Receipt_Creation.sql script */
-- expected count id 4 (may change due to daily jobs)

   SELECT count(*)
     FROM shipment sh
        , shipsku sk
    WHERE (sh.order_no,sk.item) in ((15792470,200022886),
(15792470,200022886),
(15784544,200047598),
(15824973,200032162),
(15760434,100024777),
(15830194,200022759),
(15824973,200047189),
(15824973,200047189),
(15824973,200032162),
(15824973,200047548))
      AND sh.shipment = sk.shipment
	  AND sh.invc_match_status='U'
	  AND sk.invc_match_status='U' ;
		

		
		

		