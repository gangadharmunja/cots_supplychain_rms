--creation of receipts

DECLARE

    L_error_message varchar2(4000);

               RAC_CREATE_SHIPMENT_FAIL   EXCEPTION;

BEGIN

create_shipment (15792470,888,200022886,1,291.55,2,2,L_error_message);
create_shipment (15784544,2564,200047598,5,286.39,1,1,L_error_message);
create_shipment (15824973,4284,200032162,6,628.18,2,2,L_error_message);
create_shipment (15760434,1020,100024777,1,164.63,1,1,L_error_message);
create_shipment (15830194,4017,200022759,3,223.55,1,1,L_error_message);
create_shipment (15824973,4284,200047189,5,662.97,2,2,L_error_message);
create_shipment (15824973,4284,200047548,3,337,1,1,L_error_message);


IF L_error_message IS NOT NULL THEN

      L_error_message := 'ERROR ' || L_error_message;

      dbms_output.put_line(L_error_message);     

    END IF;

   

EXCEPTION

   WHEN OTHERS THEN

      ROLLBACK;

      L_error_message := 'ERROR ' || SQLERRM;

      dbms_output.put_line(L_error_message);

END;

/
