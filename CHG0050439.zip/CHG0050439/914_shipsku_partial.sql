--this query will mark receipt records as matched  at item level
update  shipsku set qty_received=qty_matched,invc_match_status='M' 
where invc_match_status='P' 
and shipment in   ('13662241','13724371' );