--count of below query should be updated

select count(*) from shipsku where (shipment,item) in   ((13578332,200030391),
(13723795,200032206), 
(13646105,200049436), 
(13724289,200034363), 
(13652158,200022759), 
(13725564,200053756), 
(13725604,100023415), 
(13724179,200022886))
 and invc_match_status='U';




