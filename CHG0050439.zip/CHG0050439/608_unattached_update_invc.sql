-- updating doc_id
update rac_cs_sims_head set doc_id=19829749 where rac_serialized_unit_no='9999221684557';
update rac_cs_sims_head set doc_id=19829749 where rac_serialized_unit_no='9999221684556';
update rac_cs_sims_head set doc_id=19830226 where rac_serialized_unit_no='9999221685658';










