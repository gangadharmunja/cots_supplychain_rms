--count of below query should be zero after update

SELECT count(*) FROM SHIPMENT WHERE (shipment,order_no) in
(
(14221862,16200899)
)
and invc_match_status='U';