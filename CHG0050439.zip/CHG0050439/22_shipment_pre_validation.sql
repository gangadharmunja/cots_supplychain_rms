--count of below query should be updated

SELECT count(*) FROM SHIPMENT WHERE (SHIPMENT,ORDER_NO) IN
(
(14221862,16200899)
)
and invc_match_status='U';


