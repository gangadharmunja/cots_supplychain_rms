/* count should be same as no of rows should be updated */
select count(*)
from RAC_CS_SIMS_HEAD 
where rac_serialized_unit_no in 
('9999221684557',
'9999221684556',
'9999221685658'
)and doc_id is null;










