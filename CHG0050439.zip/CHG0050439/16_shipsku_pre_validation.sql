--count of below query should be updated

select count(*) from shipsku where (shipment,item) in ((14221862,200047300)) and invc_match_status='U';




