 /* below count should be same as no of records updated */
   
   SELECT count(*)
     FROM rac_im_lawsonposting_stage
        where doc_id in ('20592951',
'20592903');
		