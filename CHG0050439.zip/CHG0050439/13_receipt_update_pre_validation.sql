/* below count results no of receipts before executing Receipt_Creation.sql script */
-- expected count id 03 (may change due to daily jobs)

  select count(*) from  shipment where shipment 
 in ('16265664','14148349','14171332') and INVC_MATCH_STATUS='M';