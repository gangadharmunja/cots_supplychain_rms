--this query will mark receipt records as removed at detail level

update  shipment set invc_match_status='M' where invc_match_status='U' and (order_no,shipment) in ((15872023,13578332),
(15909888,13723795),
(15897509,13646105),
(15921130,13724289),
(15903717,13652158),
(15936296,13725564),
(15917339,13725604),
(15922522,13724179),(15937071,13662241),
                    (15936296,13724371));