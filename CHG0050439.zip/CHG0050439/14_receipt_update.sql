update shipment set INVC_MATCH_STATUS='U' where shipment in 
('16265664','14148349','14171332');