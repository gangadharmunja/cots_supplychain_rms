--this query will mark receipt records as removed at header level





update shipsku set qty_matched=-1, qty_received=-1,invc_match_status='M' where invc_match_status='U' and (shipment,item) in 
(
(14221862,200047300)
);











 
