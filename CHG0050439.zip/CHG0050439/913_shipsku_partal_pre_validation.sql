--count of below query should be update

select count(*) from shipsku where shipment in  ('13662241','13724371' )
and invc_match_status='P';




