--count of below query should be zero after update

select count(*) from shipsku where (shipment,item) in ((14221862,200047300)) and invc_match_status='U';