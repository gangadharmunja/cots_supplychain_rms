--this query will mark receipt records as removed at detail level


update  shipment set invc_match_status='M' where invc_match_status='U' and (shipment,order_no) in 
(
(14221862,16200899)
);