/* below count results no of receipts after executing Receipt_Creation.sql script */
-- expected count id 01 (may change due to daily jobs)

   SELECT count(*)
     FROM shipment sh
        , shipsku sk
    WHERE (sh.order_no,sk.item) in ((16200899,200047305))
      AND sh.shipment = sk.shipment
	  AND sh.invc_match_status='U'
	  AND sk.invc_match_status='U'
        ;