/* below count results no of receipts after executing Receipt_Creation.sql script */
-- expected count id 05 (may change due to daily jobs)

  
 select count(*) from  shipment where shipment in ('13538042','13600365','13591082','13615909','13615867') and INVC_MATCH_STATUS='U';
 
