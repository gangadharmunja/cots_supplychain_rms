/* below count results no of receipts after executing Receipt_Creation.sql script */
-- expected count id 03 (may change due to daily jobs)

   SELECT count(*)
     FROM shipment sh
        , shipsku sk
    WHERE (sh.order_no,sk.item) in ((16106021,100024415),(16197481,200055309),(16112379,200022759))
      AND sh.shipment = sk.shipment
	  AND sh.invc_match_status='U'
	  AND sk.invc_match_status='U'
        ;