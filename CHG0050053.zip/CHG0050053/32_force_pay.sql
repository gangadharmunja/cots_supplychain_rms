-- posting invoices to finance

update rac_im_lawsonposting_stage lps set lps.cs_create_date = get_vdate(),lps.cs_accounting_date =trunc(last_day(sysdate))
where doc_id in ('20294840',
'19841370',
'20282251',
'19718445',
'19709108',
'20282250',
'20294837'); 


