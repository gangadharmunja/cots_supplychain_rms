--creation of receipts

DECLARE

    L_error_message varchar2(4000);

               RAC_CREATE_SHIPMENT_FAIL   EXCEPTION;

BEGIN

create_shipment (16106021,128,100024415,1,571,1,1,L_error_message);
create_shipment (16112379,108,200022759,2,261.38,4,4,L_error_message);
create_shipment (16197481,2404,200055309,4,611.99,1,1,L_error_message);




IF L_error_message IS NOT NULL THEN

      L_error_message := 'ERROR ' || L_error_message;

      dbms_output.put_line(L_error_message);     

    END IF;

   

EXCEPTION

   WHEN OTHERS THEN

      ROLLBACK;

      L_error_message := 'ERROR ' || SQLERRM;

      dbms_output.put_line(L_error_message);

END;

/
