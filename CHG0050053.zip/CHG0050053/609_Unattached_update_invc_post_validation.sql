/* count should be zero after execution of script */

select count(*)
from RAC_CS_SIMS_HEAD where 
rac_serialized_unit_no in 
('9999221060974',
'9999221121321',
'9999221127714')
and doc_id is null; 

