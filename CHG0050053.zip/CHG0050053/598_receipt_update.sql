update shipment set INVC_MATCH_STATUS='U' where shipment in ('13538042','13600365','13591082','13615909','13615867');

