 /* below count should be same as no of records updated */
   
   SELECT count(*)
     FROM rac_im_lawsonposting_stage
        where doc_id in ('20294840',
'19841370',
'20282251',
'19718445',
'19709108',
'20282250',
'20294837');
		