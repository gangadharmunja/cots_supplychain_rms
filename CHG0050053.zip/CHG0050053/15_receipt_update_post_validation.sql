/* below count results no of receipts after executing Receipt_Creation.sql script */
-- expected count id 12 (may change due to daily jobs)

  
 select count(*) from  shipment where shipment in ('13986072','14027877','14022828','14017468','14039169','14025524','14026394','14055243','14059432','14050095','14084391','13605400') 
and INVC_MATCH_STATUS='U';