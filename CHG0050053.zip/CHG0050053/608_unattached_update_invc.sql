-- updating doc_id
update rac_cs_sims_head set doc_id=19216938 where rac_serialized_unit_no='9999221060974';
update rac_cs_sims_head set doc_id=19310194 where rac_serialized_unit_no='9999221121321';
update rac_cs_sims_head set doc_id=19308005 where rac_serialized_unit_no='9999221127714';














