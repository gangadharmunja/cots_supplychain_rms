--creation of receipts

DECLARE

    L_error_message varchar2(4000);

               RAC_CREATE_SHIPMENT_FAIL   EXCEPTION;

BEGIN

create_shipment (16188112,5589,200053647,3,611.99,2,2,L_error_message);
create_shipment (16188112,5589,200055309,4,611.99,2,2,L_error_message);
create_shipment (16183475,4272,200053647,3,611.99,1,1,L_error_message);
create_shipment (16183475,4272,200055309,4,611.99,1,1,L_error_message);
create_shipment (16185288,1344,200053647,3,611.99,1,1,L_error_message);
create_shipment (16185288,1344,200055309,4,611.99,2,2,L_error_message);



IF L_error_message IS NOT NULL THEN

      L_error_message := 'ERROR ' || L_error_message;

      dbms_output.put_line(L_error_message);     

    END IF;

   

EXCEPTION

   WHEN OTHERS THEN

      ROLLBACK;

      L_error_message := 'ERROR ' || SQLERRM;

      dbms_output.put_line(L_error_message);

END;

/
