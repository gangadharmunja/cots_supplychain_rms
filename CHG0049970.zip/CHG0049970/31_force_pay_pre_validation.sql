 /* below count should be same as no of records updated */
   
   SELECT count(*)
     FROM rac_im_lawsonposting_stage
        where doc_id in ('20254205',
'20254209',
'20248096',
'19582748');
		