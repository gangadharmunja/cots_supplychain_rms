--this query will mark receipt records as removed at detail level

update  shipment set invc_match_status='M' where invc_match_status='U' and (shipment,order_no) in 
(
(13855841,16052151),
(13952392,16108996),
(13991239,16106878),
(13962673,16095736),
(13990138,16135265),
(14073032,16188112),
(14085112,16183475),
(14083686,16185288)
);