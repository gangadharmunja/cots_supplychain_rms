/* below count results no of receipts after executing Receipt_Creation.sql script */
-- expected count id 16 (may change due to daily jobs)

   SELECT count(*)
     FROM shipment sh
        , shipsku sk
    WHERE (sh.order_no,sk.item) in ((15838178,200022759),
(15859905,200022759),
(15859905,200048622),
(15859905,200048622),
(15838178,200047189),
(15861076,200022759),
(15861076,200022759),
(15861076,200022759),
(15861076,200049436),
(15861076,200049879),
(15860280,200032162),
(15798787,100019658),
(15859761,100021515),
(15859761,100024032),
(15861076,200030089),
(15861076,100024032),
(15859905,100023412),
(15859905,100023412),
(15861076,200047548),
(15861076,200031678))
      AND sh.shipment = sk.shipment
	  AND sh.invc_match_status='U'
	  AND sk.invc_match_status='U';
		
