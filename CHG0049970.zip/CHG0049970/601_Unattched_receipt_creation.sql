--creation of receipts

DECLARE

    L_error_message varchar2(4000);

               RAC_CREATE_SHIPMENT_FAIL   EXCEPTION;

BEGIN

create_shipment (15798787,1014,100019658,3,300,1,1,L_error_message);
create_shipment (15838178,4037,200022759,6,223.55,1,1,L_error_message);
create_shipment (15838178,4037,200047189,8,662.97,1,1,L_error_message);
create_shipment (15859761,2537,100021515,7,287.9,1,1,L_error_message);
create_shipment (15859761,2537,100024032,6,413.99,1,1,L_error_message);
create_shipment (15859905,2549,200022759,5,223.55,1,1,L_error_message);
create_shipment (15859905,2549,200048622,4,316.42,2,2,L_error_message);
create_shipment (15859905,2549,100023412,1,84.48,2,2,L_error_message);
create_shipment (15860280,1002,200032162,1,628.18,1,1,L_error_message);
create_shipment (15861076,2836,200022759,5,223.55,3,3,L_error_message);
create_shipment (15861076,2836,200049436,12,724.54,1,1,L_error_message);
create_shipment (15861076,2836,200049879,10,528.37,1,1,L_error_message);
create_shipment (15861076,2836,200030089,3,334.77,1,1,L_error_message);
create_shipment (15861076,2836,100024032,1,413.99,1,1,L_error_message);
create_shipment (15861076,2836,200047548,9,337,1,1,L_error_message);
create_shipment (15861076,2836,200031678,7,711.02,1,1,L_error_message);



IF L_error_message IS NOT NULL THEN

      L_error_message := 'ERROR ' || L_error_message;

      dbms_output.put_line(L_error_message);     

    END IF;

   

EXCEPTION

   WHEN OTHERS THEN

      ROLLBACK;

      L_error_message := 'ERROR ' || SQLERRM;

      dbms_output.put_line(L_error_message);

END;

/
