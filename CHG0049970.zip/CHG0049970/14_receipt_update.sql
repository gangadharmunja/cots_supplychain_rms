update shipment set INVC_MATCH_STATUS='U' where shipment in 
('13987401','14007485','14018595','14054618');