--this query will mark receipt records as removed at header level

update shipsku set qty_matched=-1, qty_received=-1,invc_match_status='M' where invc_match_status='U' and (shipment,item) in 
(
(13855841,200053282),
(14073032,200049357),
(14073032,200053155),
(14085112,200049357),
(14085112,200053155),
(14083686,200049357),
(14083686,200053155)
);











 
