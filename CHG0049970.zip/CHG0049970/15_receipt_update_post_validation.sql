/* below count results no of receipts after executing Receipt_Creation.sql script */
-- expected count id 04 (may change due to daily jobs)

  
 select count(*) from  shipment where shipment in ('13987401','14007485','14018595','14054618') and INVC_MATCH_STATUS='U';