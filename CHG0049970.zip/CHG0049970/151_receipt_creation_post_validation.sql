/* below count results no of receipts after executing Receipt_Creation.sql script */
-- expected count id 06 (may change due to daily jobs)

   SELECT count(*)
     FROM shipment sh
        , shipsku sk
    WHERE (sh.order_no,sk.item) in ((16188112,200053647),
(16188112,200055309),
(16183475,200053647),
(16183475,200055309),
(16185288,200053647),
(16185288,200055309))
      AND sh.shipment = sk.shipment
	  AND sh.invc_match_status='U'
	  AND sk.invc_match_status='U'
        ;