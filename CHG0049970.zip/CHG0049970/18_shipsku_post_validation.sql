--count of below query should be zero after update

select count(*) from shipsku where (shipment,item) in ((13855841,200053282),
(14073032,200049357),
(14073032,200053155),
(14085112,200049357),
(14085112,200053155),
(14083686,200049357),
(14083686,200053155)) and invc_match_status='U';