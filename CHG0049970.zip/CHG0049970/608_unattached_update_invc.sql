-- updating doc_id
update rac_cs_sims_head set doc_id=19048754 where rac_serialized_unit_no='9999220919561';
update rac_cs_sims_head set doc_id=19048754 where rac_serialized_unit_no='9999220919560';
update rac_cs_sims_head set doc_id=18953640 where rac_serialized_unit_no='9999220967648';
update rac_cs_sims_head set doc_id=18953640 where rac_serialized_unit_no='9999220967649';
update rac_cs_sims_head set doc_id=19048754 where rac_serialized_unit_no='9999220988423';
update rac_cs_sims_head set doc_id=19136175 where rac_serialized_unit_no='9999220993943';
update rac_cs_sims_head set doc_id=19021408 where rac_serialized_unit_no='9999220996677';
update rac_cs_sims_head set doc_id=19173592 where rac_serialized_unit_no='9999221013979';
update rac_cs_sims_head set doc_id=19173592 where rac_serialized_unit_no='9999221013978';
update rac_cs_sims_head set doc_id=19188482 where rac_serialized_unit_no='9999221023270';
update rac_cs_sims_head set doc_id=19188482 where rac_serialized_unit_no='9999221023269';
update rac_cs_sims_head set doc_id=19173700 where rac_serialized_unit_no='9999221028874';

















