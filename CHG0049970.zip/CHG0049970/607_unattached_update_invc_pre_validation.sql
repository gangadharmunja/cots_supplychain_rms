/* count should be same as no of rows should be updated */
select count(*)
from RAC_CS_SIMS_HEAD 
where rac_serialized_unit_no in 
('9999220967648',
'9999220967649',
'9999220988423',
'9999220919560',
'9999220919561',
'9999220993943',
'9999220996677',
'9999221013979',
'9999221013978',
'9999221023270',
'9999221023269',
'9999221028874');




