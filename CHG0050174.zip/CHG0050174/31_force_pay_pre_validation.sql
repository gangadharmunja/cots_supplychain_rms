 /* below count should be same as no of records updated */
   
   SELECT count(*)
     FROM rac_im_lawsonposting_stage
        where doc_id in ('20262741',
'20262767',
'20262851',
'20473680',
'20495084',
'20262743',
'20262762',
'20262853');
		