/* below count results no of receipts before executing Receipt_Creation.sql script */
-- expected count id 06 (may change due to daily jobs)

   SELECT count(*)
     FROM shipment sh
        , shipsku sk
    WHERE (sh.order_no,sk.item) in ((16067231,200046058),(16067231,200047027),(16096213,200052658))
      AND sh.shipment = sk.shipment
	  AND sh.invc_match_status='U'
	  AND sk.invc_match_status='U'
        ;
		
