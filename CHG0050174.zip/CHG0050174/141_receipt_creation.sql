--creation of receipts

DECLARE

    L_error_message varchar2(4000);

               RAC_CREATE_SHIPMENT_FAIL   EXCEPTION;

BEGIN


create_shipment (16067231,7237,200046058,6,508.01,1,1,L_error_message);
create_shipment (16067231,7237,200047027,7,713.05,1,1,L_error_message);
create_shipment (16096213,2737,200052658,2,991.64,2,2,L_error_message);

IF L_error_message IS NOT NULL THEN

      L_error_message := 'ERROR ' || L_error_message;

      dbms_output.put_line(L_error_message);     

    END IF;

   

EXCEPTION

   WHEN OTHERS THEN

      ROLLBACK;

      L_error_message := 'ERROR ' || SQLERRM;

      dbms_output.put_line(L_error_message);

END;

/
