--count of below query should be zero after update

select count(*) from shipsku where shipment in ('13727627','13665757' )
and invc_match_status='P';
