/* this will update bol_no from rac_asnout_int_stg to rac_receipt_int_stg when both are not same */

declare

L_cnt number := 0;

cursor c_rec is
select b.rac_rcpt_int_stg_seq,b.item,b.doc_no,a.bol_no from rac_asnout_int_stg a, rac_receipt_int_stg b
where a.distro_no=b.doc_no
and a.item_no=b.item
and ((a.unit_qty>b.qty_received) or (a.unit_qty=b.qty_received))
and a.bol_no<>b.bol_no
and a.status_code='S'
AND b.STATUS_CODE='P';
begin

for c1 in c_rec
loop

update rac_receipt_int_stg 
set bol_no=c1.bol_no
where item=c1.item
and doc_no=c1.doc_no
and rac_rcpt_int_stg_seq=c1.rac_rcpt_int_stg_seq;

L_cnt := L_cnt + 1;

end loop;

DBMS_OUTPUT.PUT_LINE(L_cnt);

end;
/