-- posting invoices to finance

update rac_im_lawsonposting_stage lps set lps.cs_create_date = get_vdate(),lps.cs_accounting_date =trunc(last_day(sysdate))
where doc_id in ('20262741',
'20262767',
'20262851',
'20473680',
'20495084',
'20262743',
'20262762',
'20262853'); 


