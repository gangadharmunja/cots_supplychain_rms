  /* below count should be zero after script execution */
  
   SELECT count(*)
     FROM rac_im_lawsonposting_stage
        where doc_id in ('20262741',
'20262767',
'20262851',
'20473680',
'20495084',
'20262743',
'20262762',
'20262853') and cs_create_date is null;